
let button, input, submit, scal, curr_input, inp_size, symbol, unit_symbol;
curr_input = '0';
scal = 400;

unit_selected_value = 'meters';
ratio_selected_value = 'meters';
symbol = 'm'
unit_symbol = 'm'
//---------------------
let curr_conv_input, conv_symbol, conv_unit_symbol;
curr_conv_input = '0';

conv_unit_value = 'meters';
conv_ratio_value = 'meters';
conv_symbol = 'm';
conv_unit_symbol = 'm';

function setup() {
  if(scal < 400) {
    scal = 400
  }
  inp_size = scal/4;
  createCanvas(scal, scal);
  background(200)

}

function draw() {
  frameRate(0)
  background(200)
  create_Title()
  
  num_input_create();
  unit_sel_create();  
  ratio_sel_create();
  ratio_sel_formula();
//Conversion value for second column  
  conv_input_create();
  conv_unit_sel_create();
  conv_ratio_sel_create();
  conv_ratio_formula();
}

//--------------------------------
function num_input_create() {
  num_input = createInput(curr_input);
  num_input.size(inp_size);
  num_input.position((scal/5)-(inp_size/2),scal/8+25);
  num_input.input(num_input_event);
}

function conv_input_create() {
  conv_input = createInput(curr_conv_input);
  conv_input.size(inp_size);
  conv_input.position((scal/5)-(inp_size/2),scal/8+125);
  conv_input.input(conv_input_event);
}

//--------------------------------
function unit_sel_create() {
  unit_sel = createSelect();
  unit_sel.size('75');
  unit_sel.position((scal/5)+(inp_size/2)+10, scal/8+26);
  unit_sel.option('meters');
  unit_sel.option('hertz');
  unit_sel.option('grams');
  unit_sel.option('joules')
  unit_sel.selected(unit_selected_value);
  unit_sel.changed(myUnitSelectEvent);  
}

function conv_unit_sel_create() {
  conv_unit_sel = createSelect();
  conv_unit_sel.size('75');
  conv_unit_sel.position((scal/5)+(inp_size/2)+10, scal/8+126);
  conv_unit_sel.option('meters');
  conv_unit_sel.option('grams');
  conv_unit_sel.option('feet');
  conv_unit_sel.option('pounds')
  conv_unit_sel.selected(conv_unit_value);
  conv_unit_sel.changed(convUnitSelectEvent);  
}
//--------------------------------


function ratio_sel_create() {
  ratio_sel = createSelect();
  ratio_sel.size('100');
  ratio_sel.position((scal/5)+(inp_size/2)+110, scal/8+26)
  ratio_sel.option('Tera'+unit_selected_value)
  ratio_sel.option('Giga'+unit_selected_value)
  ratio_sel.option('Mega'+unit_selected_value)
  ratio_sel.option('Kilo'+unit_selected_value)
  ratio_sel.option('Hecto'+unit_selected_value)
  ratio_sel.option('Deca'+unit_selected_value)
  ratio_sel.option(''+unit_selected_value)
  ratio_sel.option('Deci'+unit_selected_value)
  ratio_sel.option('Centi'+unit_selected_value)
  ratio_sel.option('Milli'+unit_selected_value)
  ratio_sel.option('Micro'+unit_selected_value)
  ratio_sel.option('Nano'+unit_selected_value)
  ratio_sel.option('Pico'+unit_selected_value)
  ratio_sel.option('Femto'+unit_selected_value)
  ratio_sel.option('Atto'+unit_selected_value)
  ratio_sel.selected(ratio_selected_value);
  ratio_sel.changed(myRatioSelectEvent);
  textAlign(CENTER)
  textSize(18)
  textStyle(BOLD)
  text('to', (scal/5)+(inp_size/2)+97,scal/8+43)
}

function conv_ratio_sel_create() {
  conv_ratio_sel = createSelect();
  conv_ratio_sel.size('100');
  conv_ratio_sel.position((scal/5)+(inp_size/2)+110, scal/8+126)
  conv_ratio_sel.option('meters')
  conv_ratio_sel.option('grams')
  conv_ratio_sel.option('feet')
  conv_ratio_sel.option('pounds')
  conv_ratio_sel.selected(conv_ratio_value);
  conv_ratio_sel.changed(convRatioSelectEvent);
  textAlign(CENTER)
  textSize(18)
  textStyle(BOLD)
  text('to', (scal/5)+(inp_size/2)+97,scal/8+143)  
}

//--------------------------------
function create_Title() {
  textAlign(CENTER)
  textSize(25)
  textStyle(BOLD)
  text('Metric Conversion System',scal/2,30)
  textSize(15)
  textStyle(NORMAL)
  text('By: Jacob Coyle, Gage Dimapindan, David Bonnaud', scal/2,50)

}
//--------------------------------
function num_input_event() {
  frameRate(30)
  curr_input = this.value();
}

function conv_input_event() {
  frameRate(30)
  curr_conv_input = this.value()
}
//--------------------------------
function myUnitSelectEvent() {
  let item = unit_sel.value();
  unit_selected_value = item;
  if(item === 'meters') {
    unit_symbol = 'm';
}
  if(item === 'hertz') {
    unit_symbol = 'Hz';
}
  if(item === 'grams') {
    unit_symbol = 'g';
}
  if(item === 'joules') {
    unit_symbol = 'J';
}
ratio_selected_value = item;
  frameRate(30)
}

function convUnitSelectEvent() {
  let item = conv_unit_sel.value()
  conv_unit_value = item;
  if(item === 'meters') {
    conv_unit_symbol = 'm';
  }
  if(item === 'grams') {
    conv_unit_symbol = 'g';
  }
  if(item === 'pounds') {
    conv_unit_symbol = 'lb';
  }
  if(item === 'feet') {
    conv_unit_symbol = 'ft';
  }
conv_ratio_value = item;
  frameRate(30)
}
//--------------------------------

function myRatioSelectEvent() {
  let item = ratio_sel.value();
  ratio_selected_value = item;
  frameRate(30);
}

function convRatioSelectEvent() {
  let item = conv_ratio_sel.value();
  conv_ratio_value = item;
  frameRate(30);
}
//--------------------------------

function ratio_sel_formula() {
  textAlign(LEFT)
  textSize(20)
  let value = float(curr_input)
  if(isNaN(curr_input) === false) {
    if('Tera'+unit_selected_value === ratio_selected_value) {
      symbol = 'T'
      value = value * pow(10,-12)
    }
    if('Giga'+unit_selected_value === ratio_selected_value) {
      symbol = 'G'
      value = value * pow(10,-9)
    }
    if('Mega'+unit_selected_value === ratio_selected_value) {
      symbol = 'M'
      value = value * pow(10,-6)
    }
    if('Kilo'+unit_selected_value === ratio_selected_value) {
      symbol = 'k'
      value = value * pow(10,-3)
    }
    if('Hecto'+unit_selected_value === ratio_selected_value) {
      symbol = 'h'
      value = value * pow(10,-2)
    }
    if('Deca'+unit_selected_value === ratio_selected_value) {
      symbol = 'da'
      value = value * pow(10,-1)
    }
    if(''+unit_selected_value === ratio_selected_value) {
      symbol = ''
      value = value * pow(10,0)
    }
    if('Deci'+unit_selected_value === ratio_selected_value) {
      symbol = 'd'
      value = value * pow(10,1)
    }
    if('Centi'+unit_selected_value === ratio_selected_value) {
      symbol = 'c'
      value = value * pow(10,2)
    }
    if('Milli'+unit_selected_value === ratio_selected_value) {
      symbol = 'm'
      value = value * pow(10,3)
    }
    if('Micro'+unit_selected_value === ratio_selected_value) {
      symbol = 'µ'
      value = value * pow(10,6)
    }
    if('Nano'+unit_selected_value === ratio_selected_value) {
      symbol = 'n'
      value = value * pow(10,9)
    }
    if('Pico'+unit_selected_value === ratio_selected_value) {
      symbol = 'p'
      value = value * pow(10,12)
    }
    if('Femto'+unit_selected_value === ratio_selected_value) {
      symbol = 'f'
      value = value * pow(10,15)
    }
    if('Atto'+unit_selected_value === ratio_selected_value) {
      symbol = 'a'
      value = value * pow(10,18)
    }
    text(curr_input + " " + unit_symbol + " = " + value + " " + symbol + unit_symbol, (scal/5)-(inp_size/2), scal/8+75)
  } else {
    text("Error: Please input a number", (scal/5)-(inp_size/2), scal/8+75)
  }
}

function conv_ratio_formula() {
  textAlign(LEFT)
  textSize(20)
  let check_value1 = false;
  let check_value2 = false;
  let conv_value = float(curr_conv_input)
  if(isNaN(curr_conv_input) === false) {
    check_value2 = true;
      if(conv_unit_value === 'meters') {
          if(conv_ratio_value === 'meters'){
            check_value1 = true;
            conv_symbol = 'm';
            conv_value = conv_value * 1;
          }
          if(conv_ratio_value === 'feet') {
            check_value1 = true;
            conv_symbol = 'ft';
            conv_value = conv_value * 3.28;
          }
      }
      if(conv_unit_value === 'feet'){
          if(conv_ratio_value === 'feet') {
            check_value1 = true;
            conv_symbol = 'ft';
            conv_value = conv_value * 1;
          }
          if(conv_ratio_value === 'meters'){
            check_value1 = true;
            conv_symbol = 'm';
            conv_value = conv_value * 0.3048;
          }
      }
      if(conv_unit_value === 'grams'){
          if(conv_ratio_value === 'grams') {
            check_value1 = true;
            conv_symbol = 'g';
            conv_value = conv_value * 1;
          }
          if(conv_ratio_value === 'pounds'){
            check_value1 = true;
            conv_symbol = 'lb';
            conv_value = conv_value * 0.0022;
          }
      }
      if(conv_unit_value === 'pounds') {
          if(conv_ratio_value == 'pounds') {
            check_value1 = true;
            conv_symbol = 'lb';
            conv_value = conv_value * 1;
          }
          if(conv_ratio_value === 'grams') {
            check_value1 = true;
            conv_symbol = 'g';
            conv_value = conv_value * 453.592;
          }
      }
  }
  if(check_value2 === false){
    text("Error: Please input a number", (scal/5)-(inp_size/2), scal/8+175)
  } else if (check_value1 === false) {
    text("Error: Wrong conversion type", (scal/5)-(inp_size/2), scal/8+175)
  }
  if(check_value1 === true && check_value2 === true){
    text(curr_conv_input + " " + conv_unit_symbol + " = " + conv_value + " " + conv_symbol, (scal/5)-(inp_size/2), scal/8+175)
  }
}